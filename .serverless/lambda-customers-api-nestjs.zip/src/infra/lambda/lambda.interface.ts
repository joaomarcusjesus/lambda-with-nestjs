import { APIGatewayProxyEvent } from 'aws-lambda';

export type LambdaEvent = APIGatewayProxyEvent;
