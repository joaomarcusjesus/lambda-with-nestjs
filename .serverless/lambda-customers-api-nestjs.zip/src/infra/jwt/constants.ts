export const jwtConstants = {
  secret: 'sua senha 123',
};
