export type UserLogged = {
  user_id: number;
};
