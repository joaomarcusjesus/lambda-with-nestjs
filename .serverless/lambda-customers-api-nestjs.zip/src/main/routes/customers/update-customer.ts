import { adaptNestRouter } from '@/main/adapters/nest-router-adapter';
import { Body, Controller, Get, Param, Post, Put, Res } from '@nestjs/common';
import { Response } from 'express';
import { ApiTags } from '@nestjs/swagger';
import { CreateCustomerController } from '../../../presentation/controllers/customers/create-customer';
import { UpdateCustomerController } from '@/presentation/controllers/customers/update-customer';

@ApiTags('Customers')
@Controller('customers')
export class UpdateCustomerRouter {
  constructor(private readonly controller: UpdateCustomerController) {}

  @Put('/:id')
  async update(@Param('id') uuid: number, @Body() data, @Res() response: Response) {
    return adaptNestRouter(this.controller)(
      {
        data,
        uuid,
      },
      response,
    );
  }
}
