import { adaptNestRouter } from '@/main/adapters/nest-router-adapter';
import { Controller, Get, Param, Res } from '@nestjs/common';
import { Response } from 'express';
import { ApiTags } from '@nestjs/swagger';
import { FindCustomerController } from '@/presentation/controllers/customers/find-customer';

@ApiTags('Customers')
@Controller('customers')
export class FindCustomerRouter {
  constructor(private readonly controller: FindCustomerController) {}

  @Get('/:id')
  async list(@Param('id') uuid: number, @Res() response: Response) {
    return adaptNestRouter(this.controller)(
      {
        uuid: uuid,
      },
      response,
    );
  }
}
