import { adaptNestRouter } from '@/main/adapters/nest-router-adapter';
import { Body, Controller, Get, Param, Post, Res } from '@nestjs/common';
import { Response } from 'express';
import { ApiTags } from '@nestjs/swagger';
import { CreateCustomerController } from '../../../presentation/controllers/customers/create-customer';

@ApiTags('Customers')
@Controller('customers')
export class CreateCustomerRouter {
  constructor(private readonly controller: CreateCustomerController) {}

  @Post('/')
  async create(@Body() data, @Res() response: Response) {
    return adaptNestRouter(this.controller)(
      {
        first_name: data.first_name,
        email: data.email,
        phone: data.phone,
        last_name: data.last_name,
      },
      response,
    );
  }
}
