import { adaptNestRouter } from '@/main/adapters/nest-router-adapter';
import { Controller, Delete, Get, Param, Res } from '@nestjs/common';
import { Response } from 'express';
import { ApiTags } from '@nestjs/swagger';
import { FindCustomerController } from '@/presentation/controllers/customers/find-customer';
import { DeleteCustomerController } from '@/presentation/controllers/customers/delete-customer';

@ApiTags('Customers')
@Controller('customers')
export class DeleteCustomerRouter {
  constructor(private readonly controller: DeleteCustomerController) {}

  @Delete('/:id')
  async delete(@Param('id') uuid: number, @Res() response: Response) {
    return adaptNestRouter(this.controller)(
      {
        uuid: uuid,
      },
      response,
    );
  }
}
