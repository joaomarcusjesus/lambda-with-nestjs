import { adaptNestRouter } from '@/main/adapters/nest-router-adapter';
import { ListCustomerController } from '@/presentation/controllers/customers/list-customer';
import { Controller, Get, Res } from '@nestjs/common';
import { Response } from 'express';
import { ApiTags } from '@nestjs/swagger';

@ApiTags('Customers')
@Controller('customers')
export class ListCustomerRouter {
  constructor(private readonly controller: ListCustomerController) {}

  @Get('/')
  async list(@Res() response: Response) {
    return adaptNestRouter(this.controller)({}, response);
  }
}
