export const mockHttpCustomer = () => ({
  first_name: 'John',
  last_name: 'Doe',
  email: 'johndoe@gmail.com',
  phone: '5583999351425',
});
