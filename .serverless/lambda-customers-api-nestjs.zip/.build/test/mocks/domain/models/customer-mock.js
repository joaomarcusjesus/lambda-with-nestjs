"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mockCustomer = void 0;
const mockCustomer = () => ({
    uuid: 'uuid',
    first_name: 'John',
    last_name: 'Doe',
    email: 'johndoe@gmail.com',
    phone: '5583999351425',
});
exports.mockCustomer = mockCustomer;
//# sourceMappingURL=customer-mock.js.map