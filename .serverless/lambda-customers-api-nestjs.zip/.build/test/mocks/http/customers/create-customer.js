"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mockHttpCustomer = void 0;
const mockHttpCustomer = () => ({
    first_name: 'John',
    last_name: 'Doe',
    email: 'johndoe@gmail.com',
    phone: '5583999351425',
});
exports.mockHttpCustomer = mockHttpCustomer;
//# sourceMappingURL=create-customer.js.map