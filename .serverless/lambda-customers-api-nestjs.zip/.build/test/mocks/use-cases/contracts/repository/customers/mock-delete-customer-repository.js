"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MockDeleteCustomerRepository = void 0;
class MockDeleteCustomerRepository {
    async delete(_input) {
        return;
    }
}
exports.MockDeleteCustomerRepository = MockDeleteCustomerRepository;
//# sourceMappingURL=mock-delete-customer-repository.js.map