"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MockUpdateCustomerRepository = void 0;
class MockUpdateCustomerRepository {
    async update(_input) {
        return;
    }
}
exports.MockUpdateCustomerRepository = MockUpdateCustomerRepository;
//# sourceMappingURL=mock-update-customer-repository.js.map