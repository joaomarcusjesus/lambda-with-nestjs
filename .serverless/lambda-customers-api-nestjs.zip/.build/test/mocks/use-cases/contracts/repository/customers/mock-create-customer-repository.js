"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MockCreateCustomerRepository = void 0;
class MockCreateCustomerRepository {
    async create(_input) {
        return;
    }
}
exports.MockCreateCustomerRepository = MockCreateCustomerRepository;
//# sourceMappingURL=mock-create-customer-repository.js.map