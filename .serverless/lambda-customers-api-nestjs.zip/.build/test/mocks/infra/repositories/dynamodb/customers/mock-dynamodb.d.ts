export declare const mockCustomerDynamodb: () => {
    id: string;
    first_name: string;
    last_name: string;
    email: string;
    phone: string;
};
export declare const mockDynamodbList: () => {
    Items: {
        id: string;
        first_name: string;
        last_name: string;
        email: string;
        phone: string;
    }[];
};
