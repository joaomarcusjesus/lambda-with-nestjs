export declare const responseDecorator: (statusCode: number, data: any) => {
    statusCode: number;
    message: string;
    body: string;
};
