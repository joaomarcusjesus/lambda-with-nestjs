export declare const router: (event: APIGatewayProxyEvent) => Promise<any>;
