import { HttpResponse } from '../../../presentation/helpers/http';
export declare const router: (event: APIGatewayProxyEvent) => Promise<HttpResponse>;
