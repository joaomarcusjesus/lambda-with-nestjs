interface AttributeMap {
    [key: string]: any;
}
export type CustomerEntity = AttributeMap;
export {};
