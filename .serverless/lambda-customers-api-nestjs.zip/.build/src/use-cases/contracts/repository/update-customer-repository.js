"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateCustomerRepository = void 0;
class UpdateCustomerRepository {
}
exports.UpdateCustomerRepository = UpdateCustomerRepository;
//# sourceMappingURL=update-customer-repository.js.map