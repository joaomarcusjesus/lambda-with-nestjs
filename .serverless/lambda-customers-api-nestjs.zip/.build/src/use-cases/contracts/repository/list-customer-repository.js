"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ListCustomerRepository = void 0;
class ListCustomerRepository {
}
exports.ListCustomerRepository = ListCustomerRepository;
//# sourceMappingURL=list-customer-repository.js.map