"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeleteCustomerRepository = void 0;
class DeleteCustomerRepository {
}
exports.DeleteCustomerRepository = DeleteCustomerRepository;
//# sourceMappingURL=delete-customer-repository.js.map