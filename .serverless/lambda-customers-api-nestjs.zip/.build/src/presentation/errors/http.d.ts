export declare class ServerError extends Error {
    constructor(error?: Error);
}
